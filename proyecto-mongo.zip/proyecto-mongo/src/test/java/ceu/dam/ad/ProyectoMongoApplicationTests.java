package ceu.dam.ad;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoMongoApplicationTests {

	@Test
	void contextLoads() {
	}

}
