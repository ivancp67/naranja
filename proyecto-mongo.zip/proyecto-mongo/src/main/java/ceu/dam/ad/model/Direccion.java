package ceu.dam.ad.model;

import lombok.Data;

@Data
public class Direccion {

	private String ciudad;
	private String cp;

}
