package ceu.dam.javafx.holaMundo;


public class Launcher {

	public static void main(String[] args) {
		App.main(args);
	}
}	
