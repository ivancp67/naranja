package ceu.dam.javafx.holaMundo.gui;


public class FXMLPaths {

	public static String HOLA_MUNDO = "/ceu/dam/javafx/gui/holaMundo/HolaMundo.fxml";
}
